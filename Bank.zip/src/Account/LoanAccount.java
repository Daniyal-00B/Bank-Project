package Account;

public class LoanAccount extends Account{
}
