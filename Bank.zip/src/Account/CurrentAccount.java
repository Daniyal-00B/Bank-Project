package Account;

public class CurrentAccount extends Account {
}
