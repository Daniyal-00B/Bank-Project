package Account;

public class ShortTermAccount extends Account{
}
