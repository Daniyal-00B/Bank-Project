package Bank;

public class BaseLoan {
    private int amountOfLoan;
    private int paymentPeriod;

    public int getAmountOfLoan() {
        return amountOfLoan;
    }

    public void setAmountOfLoan(int amountOfLoan) {
        this.amountOfLoan = amountOfLoan;
    }

    public int getPaymentPeriod() {
        return paymentPeriod;
    }

    public void setPaymentPeriod(int paymentPeriod) {
        this.paymentPeriod = paymentPeriod;
    }
}
