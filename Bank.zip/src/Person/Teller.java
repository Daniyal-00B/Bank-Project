package Person;

public class Teller extends Employee{
    public Teller(String workPlace,int type){
        super(workPlace,type);
    }

    public void acceptRequests(){}
}
