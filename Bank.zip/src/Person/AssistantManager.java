package Person;

public class AssistantManager extends Employee{
    public AssistantManager(String workPlace){
        super(workPlace, 1);
    }
    public void acceptRequests(){}
}
