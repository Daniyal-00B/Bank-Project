package Person;

import Bank.Branch;

public class BranchManager extends Employee {

    public BranchManager(String workPlace){
        super(workPlace,0);
    }

    //receive employee list
    public void closeAccount(){}
    public void acceptRequests(){}
}
